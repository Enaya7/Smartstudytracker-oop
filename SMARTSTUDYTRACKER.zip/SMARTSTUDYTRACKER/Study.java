class Study {

    // V1.0 AND V2.0: BASE CLASS AND ENCAPSULATION
    // ENCAPSULATION:FOR SECURE DATA
    private String subject;
    private int hours;
    private boolean completed;

    // Setter for subject: CONTROLLED DAAT ENTRY
    public void setSubject(String subject) {
        this.subject = subject;
    }

    // Getter for subject: FOR CONTROLLED DATA RETRIEVAL
    public String getSubject() {
        return subject;
    }

    // Setter for hours
    public void setHours(int hours) {
        if(hours >= 0) {
            this.hours = hours;
     }
     else{
       System.out.println("Error: study hour can not be negative");
     }
    }

    // Getter for hours
    public int getHours() {
        return hours;
    }

    // Setter for completed
    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    // Getter for completed
    public boolean getCompleted() {
        return completed;
    }
// BASE METHOD THAT CAN BE OVERRIDDEN BY SUBCLASSES
    void startStudy() {
        System.out.println(subject + " study session started.");
    }

    // Extra method
    void showStatus() {
        if(completed == true) {
            System.out.println(subject + " study is completed.");
        }
        else {
            System.out.println(subject + " study is not completed.");
        }
    }
  // Method Overloading USING SUPER CLASS METHOD
    void completeTask() {
        System.out.println("Task completed.");
    }

    void completeTask(String taskName) {
        System.out.println(taskName + " completed.");
    }
}
